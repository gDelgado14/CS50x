<form action="reset.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autofocus class="form-control" name="opswrd" placeholder="Old Password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="npswrd" placeholder="New Password" type="password"/>
        </div>
    
        <div class="form-group">
            <input class="form-control" name="confirmation" placeholder="Retype New Password" type="password"/>
        </div>
        
        <div class="form-group">
            <button type="submit" class="btn btn-default">Register</button>
        </div>
    </fieldset>
</form>
<div>
    or <a href="/">return</a>
</div>
