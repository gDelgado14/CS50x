            </div>
            <div>
            <?php if(isset($_SESSION["username"])): ?>
               <a href="reset.php"> reset password </a>
            <?php endif ?>
            
            </div>
            <div id="bottom">
                Copyright &#169; Giorgio Delgado 2014
            </div>

        </div>

    </body>

</html>
